# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['deathstar']

package_data = \
{'': ['*']}

install_requires = \
['rich>=12.5.1,<13.0.0']

setup_kwargs = {
    'name': 'deathstar',
    'version': '0.1.0',
    'description': 'This python package allows running the deathstar',
    'long_description': None,
    'author': 'Lord Vader',
    'author_email': 'darth.vader@galactic-empire.star',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
