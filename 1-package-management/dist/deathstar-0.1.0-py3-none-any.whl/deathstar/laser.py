import rich


def fire(planet: str):
    rich.print(f"💥 Firing laster at [red]{planet}[/red]")
